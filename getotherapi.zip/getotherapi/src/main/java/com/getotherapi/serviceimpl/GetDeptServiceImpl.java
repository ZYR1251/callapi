package com.getotherapi.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.getotherapi.dao.GetDeptDao;
import com.getotherapi.entity.GetDept;
import com.getotherapi.service.GetDeptService;
@Service
public class GetDeptServiceImpl implements GetDeptService{

	@Autowired
	private GetDeptDao getDeptDao;
	public boolean insertDept(GetDept getDept) {
		        boolean flag=false;
		        try{
		        	getDeptDao.insertDept(getDept);
		            flag=true;
		        }catch(Exception e){
		            e.printStackTrace();
		        }
		        return flag;
		    }
		
		
	
	public GetDept[] getmessaage() {
		
		// TODO 自动生成的方法存根
				//https://www.cnblogs.com/loveLands/articles/9882306.html
				//RestTemplate是Spring Web模块提供的一个基于Rest规范提供Http请求的工具。应用中如果需要访问第三方提供的Rest接口，使用RestTemplate操作将非常方便。RestTemplate中提供了一系列的getXXX、postXXX、putXXX、deleteXXX等方法，以供发起对应的Rest规范请求，以及更通用的exchange和execute系列方法。
				//发起GET请求:
					//通过getForObject可以发起GET请求，下面的代码中就展示了通过getForObject发起GET请求，第二个参数指定返回类型，指定String则表示以文本形式进行返回。
					//RestTemplate restTemplate = new RestTemplate();
					//String response = restTemplate.getForObject("https://www.so.com/s?ie=utf-8&q=中国", String.class);
					//System.out.println(response);
		
		RestTemplate restTemplate=new RestTemplate();//借助 RestTemplate，Spring应用能够方便地使用REST资源,RestTemplate定义了36个与REST资源交互的方法
		System.out.println("获取数据...");
		String url = "http://127.22.60.28:8083/api/user/userAll";
		GetDept[] result = restTemplate.getForObject(url, GetDept[].class);//getForObject() 发送一个HTTP GET请求，返回的请求体将映射为一个对象
		System.out.println(result);
		return result;
		
		
	}
}
