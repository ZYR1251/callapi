package com.getotherapi.service;
import com.getotherapi.entity.GetDept;

public interface GetDeptService {
	boolean insertDept(GetDept getDept);
	public GetDept[] getmessaage();//从SSM接口获取信息
}
