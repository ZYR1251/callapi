package com.getotherapi.dao;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;

import com.getotherapi.entity.GetDept;


@Mapper
public interface GetDeptDao {
	 @Insert("insert into usertab(id,name,age) values (#{id},#{name},#{age})")
    void insertDept(GetDept getDept);
}
