package com.getotherapi.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.getotherapi.entity.GetDept;
import com.getotherapi.service.GetDeptService;

@RestController
@RequestMapping(value = "/api")
public class GetDeptController {

	@Autowired
	private GetDeptService getDeptService;
	@RequestMapping(value = "/insert",method = RequestMethod.GET)
	
	public boolean insertDept(GetDept getDept) {
       
		System.out.println("开始从ssm接口获取数据");
		GetDept[] depts = getDeptService.getmessaage();
		for(GetDept dept:depts) {
			System.out.println("插入数据");
			getDeptService.insertDept(dept);
		}
		return true;
		
		
	}
}
